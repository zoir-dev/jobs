import Collaboration from "@/components/Collaboration/Collaboration";
import Contact from "@/components/Contact/Contact";
import FindJob from "@/components/FindJob/FindJob";
import Footer from "@/components/Footer/Footer";
import Header from "@/components/Header/Header";
import Main from "@/components/Main/Main";
import Numbers from "@/components/Numbers/Numbers";
import Solutions from "@/components/Solutions/Solutions";
import UsingPlatforma from "@/components/UsingPlatform/UsingPlatforma";

export default function Home() {
  return (
    <div className="home_div">
      <Header />
      <Main />
      <UsingPlatforma />
      <Solutions />
      <Numbers />
      <FindJob />
      <Collaboration />
      <Contact />
      <Footer />
    </div>
  );
}
