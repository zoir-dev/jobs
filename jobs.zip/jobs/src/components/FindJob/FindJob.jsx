import React from "react";

const FindJob = () => {
  return <div>FindJob</div>;
};

export default FindJob;
