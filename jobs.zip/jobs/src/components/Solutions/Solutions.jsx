import React from "react";

const Solutions = () => {
  return <div>Solutions</div>;
};

export default Solutions;
