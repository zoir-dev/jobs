import React from "react";

const UsingPlatforma = () => {
  return (
    <div className="usingPlatforma_div">
      <div className="using_left">
        <h2>
          Platformadan qanday <span>foydalanamiz?</span>
        </h2>
        <p>
          Worse linen an civil jokes leave offer. Parties all clothes removal
          cheered calling prudent her and residence for met the estimable
          disposing.
        </p>
      </div>
      <div className="using_right"></div>
    </div>
  );
};

export default UsingPlatforma;
