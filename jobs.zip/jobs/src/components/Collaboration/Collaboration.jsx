import React from "react";

const Collaboration = () => {
  return <div>Collaboration</div>;
};

export default Collaboration;
