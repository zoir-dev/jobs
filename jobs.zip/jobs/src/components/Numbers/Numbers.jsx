import React from "react";

const Numbers = () => {
  return <div>Numbers</div>;
};

export default Numbers;
